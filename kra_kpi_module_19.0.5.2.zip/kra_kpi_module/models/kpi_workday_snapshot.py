# A frozen picture of one developer's day, drawn when they End Workday.
#
# WHY AN IMAGE AND NOT A REPORT: the End Workday summary is computed live and
# thrown away. productive_seconds / presence_seconds are NON-stored computes
# (kpi_work_session.py says so explicitly), and action_end_day stamps only
# logout_at / state / note. So the summary is retroactively mutable — edit a time
# log next week and a day closed today silently reports different numbers; complete
# a task tomorrow and *yesterday's* map re-renders as "Completed". There is no
# record of what the day actually looked like at End Workday. This is that record.
#
# WHY IT IS DRAWN SERVER-SIDE (Pillow) AND NOT SCREENSHOTTED IN A BROWSER:
#   * The midnight cron (_close_overdue) has NO browser — and it fires for exactly
#     the developers who forgot to end their day. A screenshot can never cover them.
#   * The phone app cannot screenshot itself (react-native-view-shot isn't installed).
#   * jsPDF / html2canvas here are CDN-loaded, so client rendering dies offline.
#   * _daily_summary_payload is already presentation-ready (every number has a
#     *_display string, every time is pre-localized).
# One server path covers web + app + cron.

import base64
import io
import logging
import re

from dateutil.relativedelta import relativedelta
from psycopg2 import IntegrityError

from odoo import api, fields, models

_logger = logging.getLogger(__name__)

# Canvas
IMG_W = 980
PAD = 26

# Palette — mirrors AWAY_COLORS in kpi_action.js and WorkdayMapChip in the app.
C_INK = '#0F172A'
C_MUTED = '#64748B'
C_LINE = '#E2E8F0'
C_BG = '#FFFFFF'
C_PANEL = '#F8FAFC'
C_GREEN = '#16A34A'
C_RED = '#DC2626'
C_BLUE = '#1E40AF'
# Paused. The same amber the app uses for every paused marker, so the saved
# image and the screen agree; C_MUTED read as disabled text beside two figures
# that carry colour.
C_AMBER = '#B45309'
AWAY_COLORS = {
    'break': '#F59E0B', 'lunch': '#10B981', 'meeting': '#3B82F6',
    'away': '#6B7280', 'leave': '#8B5CF6', 'urgent': '#EF4444',
    'no_tasks': '#0891B2', 'other': '#F59E0B',
}
OUTCOME_COLORS = {
    'completed': '#16A34A', 'submitted': '#0D9488', 'paused': '#F59E0B',
    'active': '#3B82F6', 'worked': '#64748B', 'moved': '#F97316',
}

# Pillow with a normal TTF draws colour emoji as TOFU BOXES. The timeline keeps
# its icon in a separate key so labels are already clean, but names and typed
# notes are free text and can contain anything. Strip rather than gamble.
_EMOJI_RE = re.compile(
    '[\U0001F000-\U0001FAFF\U00002190-\U000021FF\U00002300-\U000027BF'
    '\U00002B00-\U00002BFF\U0000FE00-\U0000FE0F\U0001F1E6-\U0001F1FF]+',
    flags=re.UNICODE)

# Font candidates, best first. DejaVuSans is NOT present on this box and Pillow
# ships no fonts dir here — verified, not assumed — so Windows UI fonts lead and
# load_default(size=) is the real backstop.
_FONT_CANDIDATES = (
    r'C:\Windows\Fonts\segoeui.ttf',
    r'C:\Windows\Fonts\arial.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    'DejaVuSans.ttf',
)
_FONT_BOLD_CANDIDATES = (
    r'C:\Windows\Fonts\segoeuib.ttf',
    r'C:\Windows\Fonts\arialbd.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    'DejaVuSans-Bold.ttf',
)


def _clean(text):
    """Emoji-free, single-line text safe to hand to Pillow."""
    s = '' if text is None else str(text)
    s = _EMOJI_RE.sub('', s)
    s = s.replace('\r', ' ').replace('\n', ' ')
    return ' '.join(s.split()).strip()


class KpiWorkdaySnapshot(models.Model):
    _name = 'kpi.workday.snapshot'
    _description = 'Frozen End-Workday summary image (one per developer per day)'
    _order = 'session_date desc, id desc'

    user_id = fields.Many2one(
        'res.users', string='Developer', required=True, index=True, ondelete='cascade')
    session_date = fields.Date(string='Day', required=True, index=True)

    # attachment=True keeps bytes in the FILESTORE, not a db bytea column — the
    # house rule (see the comment on kpi.user.manual.manual_file). In-DB blobs
    # bloat the database and every backup forever.
    image = fields.Binary(string='Summary Image', attachment=True)
    image_name = fields.Char(string='File Name')

    # STORED on purpose — this is the snapshot. The live computes on
    # kpi.work.session will drift; these must not.
    presence_seconds = fields.Float(string='Presence (s)')
    productive_seconds = fields.Float(string='Productive (s)')
    # THREE eras of `presence_seconds`, and this column is how you tell them
    # apart. Originally presence subtracted paused time; 19.0.2.6 made it the raw
    # login->logout clock with pauses included; it now subtracts again, because
    # Pause Workday is meant to stop the clock.
    #
    # Pre-19.0.2.6 rows cannot be recomputed — the underlying sessions may be
    # gone and paused was never stored — and are deliberately NOT backfilled: an
    # old row reads 0.0 here, so read a zero-paused row as "unknown", not as "the
    # day had no pauses". 19.0.2.6-era rows DO carry paused, so a stored presence
    # from that window is the raw clock and its at-work figure is
    # presence - paused. Nothing is rewritten either way: a snapshot is a record
    # of what was reported on the day, not a view that follows the definition.
    paused_seconds = fields.Float(string='Paused (s)')
    standard_hours = fields.Float(string='Standard Day (h)')
    met_standard = fields.Boolean(string='Met the Standard Day')
    task_count = fields.Integer(string='Tasks Touched')
    # What the developer wrote when they ended the day. Copied from
    # kpi.work.session.note at capture time so the snapshot is a complete record on its
    # own — the session can be reopened and re-ended, and this freezes what was said at
    # the moment the day was closed.
    #
    # Deliberately NOT drawn into the image: that layout is fixed and a dozen lines of
    # prose would either overflow it or shrink to unreadable. It lives on the row, which
    # is also the part that survives the retention cron (only the PNG is cleared).
    note = fields.Text(string='End-of-Day Note')
    # If an admin reopened this day, why. Copied off the session at capture time: the
    # reopen happens between one End Workday and the next, so by the time the day is
    # re-ended the session still carries the reason and this freezes it next to the
    # figures it explains. Without it the day silently shows different numbers from the
    # summary someone already received, with nothing saying a human reopened it.
    reopen_reason = fields.Text(string='Reopened Because', readonly=True)
    reopened_by_id = fields.Many2one('res.users', string='Reopened By', readonly=True)
    reopened_at = fields.Datetime(string='Reopened At', readonly=True)
    generated_at = fields.Datetime(string='Generated At')

    # Set when an admin reopens the day this image was drawn for. The image is
    # kept, not deleted: it is the only record of what the day looked like at
    # End Workday, and notifications already link to it. This flag is what stops
    # it being read as the final word once work resumed. It is cleared again by
    # _capture, so the next close overwrites the row and un-supersedes it.
    superseded = fields.Boolean(
        string='Superseded by a reopened day', default=False, copy=False,
        help='An admin reopened this workday after this summary was frozen, so '
             'the numbers here are no longer the whole day.')

    # ONE image per developer per day. A restart after an accidental End Workday
    # redraws this same row rather than adding a second, so the last redraw is the
    # complete day.
    #
    # models.Constraint, NOT _sql_constraints: Odoo 19 SILENTLY IGNORES the old
    # attribute — no error, no constraint, no clue. A probe caught this (the DB
    # cheerfully took a duplicate). Matches kra.kpi._kpi_approval_token_uniq and
    # Odoo 19 core (res_users._login_key).
    _uniq_user_day = models.Constraint(
        'UNIQUE (user_id, session_date)',
        'A workday snapshot already exists for this developer and day.',
    )

    # ------------------------------------------------------------------ #
    # Fonts                                                              #
    # ------------------------------------------------------------------ #
    @api.model
    def _font(self, size, bold=False):
        from PIL import ImageFont
        for path in (_FONT_BOLD_CANDIDATES if bold else _FONT_CANDIDATES):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
        try:
            return ImageFont.load_default(size=size)
        except Exception:
            # Ancient Pillow: load_default() takes no size. Ugly but never fatal —
            # a missing font must not stop someone ending their day.
            return ImageFont.load_default()

    # ------------------------------------------------------------------ #
    # The renderer                                                       #
    # ------------------------------------------------------------------ #
    @api.model
    def _render_summary_image(self, p):
        """Draw the End Workday summary. Pure function of the payload dict from
        kpi.work.session._daily_summary_payload(full_day=True). Returns PNG bytes."""
        from PIL import Image, ImageDraw

        f_h1 = self._font(26, bold=True)
        f_h2 = self._font(15, bold=True)
        f_big = self._font(30, bold=True)
        f_lbl = self._font(12)
        f_txt = self._font(13)
        f_bold = self._font(13, bold=True)
        f_small = self._font(11)

        # Draw on a generously tall canvas, then crop to what we used. Simpler and
        # safer than trying to pre-compute the height of a variable-length map.
        img = Image.new('RGB', (IMG_W, 4000), C_BG)
        d = ImageDraw.Draw(img)

        def text(xy, s, font, fill=C_INK):
            d.text(xy, _clean(s), font=font, fill=fill)

        def width(s, font):
            return d.textlength(_clean(s), font=font)

        def ellipsize(s, font, maxw):
            s = _clean(s)
            if width(s, font) <= maxw:
                return s
            while s and width(s + '…', font) > maxw:
                s = s[:-1]
            return (s + '…') if s else ''

        met = bool(p.get('met_standard'))
        verdict = C_GREEN if met else C_RED
        y = PAD

        # ---- Header -------------------------------------------------------
        d.rounded_rectangle([PAD, y, IMG_W - PAD, y + 78], radius=12, fill=C_BLUE)
        text((PAD + 18, y + 14), 'Workday Summary — %s' % p.get('dev', ''), f_h1, '#FFFFFF')
        # login_at/logout_at are full "YYYY-MM-DD HH:MM:SS" strings and the date is
        # already in the line — show clock times only, or it reads the date 3 times.
        # And say "to", not an arrow: U+2192 sits in the range _clean() strips, so
        # an arrow here silently vanishes (it did).
        def _hhmm(s):
            s = _clean(s)
            return s.split(' ')[1][:5] if ' ' in s else s
        sub = '%s   ·   %s to %s' % (
            p.get('session_date', ''),
            _hhmm(p.get('login_at', '')) or '—',
            _hhmm(p.get('logout_at', '')) or 'still working')
        text((PAD + 18, y + 48), sub, f_lbl, '#C7D8F7')
        y += 78 + 16

        # ---- Stat tiles ---------------------------------------------------
        tiles = [
            ('Productive (task time)', p.get('productive_display', '0m'), C_GREEN, ''),
            # Words, not a tick: U+2713 is inside the emoji range _clean() strips,
            # and "over/under" says it plainly anyway. Colour carries it too.
            ('Presence (at work)', p.get('presence_display', '0m'), verdict,
             '%s %s standard' % ('over' if met else 'under', p.get('standard_display', ''))),
            # Everything the day is accounted for by, in one number: task work +
            # meeting + lunch + break + no-tasks (+ away/other) + paused.
            # Accounted plus Other/Idle is exactly the CLOCK -- not Presence, now
            # that the pause sits outside Presence and inside this.
            ('Accounted', p.get('accounted_display', '0m'), C_INK,
             'task+meet+lunch+break+paused'),
            ('Tasks touched', str(p.get('task_count', 0)), C_INK, ''),
        ]
        # Only when the day was actually paused — an always-present "0m Paused"
        # tile would just make every normal day look like it had a gap.
        if (p.get('paused_seconds') or 0) > 0:
            tiles.append(('Workday paused', p.get('paused_display', '0m'), C_AMBER,
                          'outside Presence'))
        # Width derived from the tile COUNT — it was hardcoded to 3, so adding a
        # tile silently drew it off the edge of the image.
        tw = (IMG_W - PAD * 2 - (len(tiles) - 1) * 12) / float(len(tiles))

        def _x0(i):
            return PAD + i * (tw + 12)

        # Presence and Accounted are drawn as ONE box divided by a rule, the same
        # pairing the app popup and the web popup use: Presence is time at work,
        # Accounted is the day explained, and the gap between them IS the pause.
        # Only the OUTLINES change here -- every label keeps the exact x it would
        # have had, so the rest of the row is untouched and nothing reflows.
        #
        # Found by label rather than hardcoded: the list above has grown before
        # (the paused tile), and an index would silently pair the wrong two boxes
        # the next time something is inserted above them.
        pair_i = next((i for i, t in enumerate(tiles)
                       if t[0].startswith('Presence')), -1)
        for i, (lbl, val, col, foot) in enumerate(tiles):
            if i == pair_i:
                d.rounded_rectangle([_x0(i), y, _x0(i + 1) + tw, y + 92], radius=10,
                                    fill=C_PANEL, outline=C_LINE)
                d.line([_x0(i + 1) - 6, y + 10, _x0(i + 1) - 6, y + 82],
                       fill=C_LINE, width=1)
            elif i != pair_i + 1:
                d.rounded_rectangle([_x0(i), y, _x0(i) + tw, y + 92], radius=10,
                                    fill=C_PANEL, outline=C_LINE)
            text((_x0(i) + 14, y + 12), lbl, f_lbl, C_MUTED)
            text((_x0(i) + 14, y + 32), val, f_big, col)
            if foot:
                text((_x0(i) + 14, y + 70), foot, f_small, col)
        y += 92 + 18

        # ---- Away time ----------------------------------------------------
        text((PAD, y), 'Away time  (inside Presence — never Productive)', f_h2, C_INK)
        y += 24
        away = [
            ('Break', p.get('break_display')), ('Lunch', p.get('lunch_display')),
            ('Meeting', p.get('meeting_display')), ('No tasks', p.get('no_tasks_display')),
            ('Other', p.get('other_display')), ('Away (system)', p.get('away_display')),
            ('Other / Idle', p.get('other_idle_display')),
        ]
        aw = (IMG_W - PAD * 2 - 6 * 8) / 7.0
        for i, (lbl, val) in enumerate(away):
            x0 = PAD + i * (aw + 8)
            d.rounded_rectangle([x0, y, x0 + aw, y + 54], radius=8,
                                fill='#FFFBEB', outline='#FDE68A')
            text((x0 + 8, y + 8), lbl, f_small, C_MUTED)
            text((x0 + 8, y + 26), val or '0m', f_bold, C_INK)
        y += 54 + 20

        # ---- Workday Map --------------------------------------------------
        text((PAD, y), 'Workday Map  (your day in order)', f_h2, C_INK)
        y += 24
        for n in (p.get('timeline') or []):
            kind = n.get('kind')
            if kind == 'break':
                col = AWAY_COLORS.get(n.get('break_type'), '#F59E0B')
            elif kind == 'task':
                col = OUTCOME_COLORS.get(n.get('outcome'), '#64748B')
            else:
                col = '#94A3B8'
            # "with X, Y — the reason". One line, because the row only has one:
            # the participants and the note are separate keys precisely so this
            # can decide how to join them, rather than receiving them pre-glued.
            note = n.get('reason') or ''
            who = n.get('with') or ''
            if who:
                note = ('with %s — %s' % (who, note)).rstrip(' —') if note else 'with %s' % who
            row_h = 40 if not note else 56
            d.rounded_rectangle([PAD, y, IMG_W - PAD, y + row_h], radius=8,
                                fill=C_PANEL, outline=C_LINE)
            # Left colour bar carries the meaning the emoji used to.
            d.rounded_rectangle([PAD, y, PAD + 5, y + row_h], radius=2, fill=col)
            text((PAD + 16, y + 9), ellipsize(n.get('label'), f_bold, 560), f_bold, C_INK)
            when = n.get('time') or ''
            if n.get('duration_display'):
                when = ('%s · %s' % (when, n['duration_display'])).strip(' ·')
            if when:
                text((IMG_W - PAD - 12 - width(when, f_txt), y + 10), when, f_txt, C_MUTED)
            if note:
                text((PAD + 16, y + 32), ellipsize(note, f_small, IMG_W - PAD * 2 - 40),
                     f_small, C_MUTED)
            y += row_h + 6
        y += 14

        # ---- Tasks --------------------------------------------------------
        tasks = p.get('tasks') or []
        text((PAD, y), 'Tasks worked today (%d)' % len(tasks), f_h2, C_INK)
        y += 24
        if tasks:
            d.line([PAD, y, IMG_W - PAD, y], fill=C_LINE, width=1)
            y += 8
            for t in tasks:
                ref = str(t.get('ref') or '')
                text((PAD + 4, y), ref, f_txt, C_MUTED)
                name = ellipsize(t.get('name'), f_txt, IMG_W - PAD * 2 - 240)
                if t.get('concurrent'):
                    name = '* ' + name    # multi-tasked; '⚡' would be tofu
                text((PAD + 90, y), name, f_txt, C_INK)
                dur = t.get('duration_display') or ''
                text((IMG_W - PAD - 4 - width(dur, f_bold), y), dur, f_bold, C_INK)
                y += 22
                # Only worth a second line when the task was BOTH: time on its own
                # and time shared with another task. A wholly-shared task already
                # says so with the '*'.
                if t.get('concurrent') and (t.get('solo_seconds') or 0) > 0:
                    split = '%s alone + %s shared' % (t.get('solo_display') or '',
                                                      t.get('shared_display') or '')
                    text((PAD + 90, y), split, f_txt, C_MUTED)
                    y += 18
        else:
            text((PAD + 4, y), 'No tasks were worked on this day.', f_txt, C_MUTED)
            y += 22
        y += 6

        if p.get('note'):
            text((PAD, y), 'Note: %s' % ellipsize(p['note'], f_txt, IMG_W - PAD * 2 - 60),
                 f_txt, C_MUTED)
            y += 24

        img = img.crop((0, 0, IMG_W, min(4000, int(y) + PAD)))
        buf = io.BytesIO()
        img.save(buf, format='PNG', optimize=True)
        return buf.getvalue()

    # ------------------------------------------------------------------ #
    # Save                                                               #
    # ------------------------------------------------------------------ #
    @api.model
    def _capture(self, session, payload):
        """Draw + store the day's image. ONE row per (developer, day): a restart
        after an accidental End Workday redraws this row rather than adding a
        second, so the last redraw is the complete day.

        Returns the snapshot record, or an empty recordset on failure — the
        caller must never let a drawing bug block someone ending their day.
        """
        try:
            png = self._render_summary_image(payload)
        except Exception as exc:
            _logger.exception("workday snapshot render failed for %s: %s",
                              session.user_id.login, exc)
            return self.browse()

        vals = {
            'user_id': session.user_id.id,
            'session_date': session.session_date,
            'image': base64.b64encode(png),
            'image_name': 'workday-%s-%s.png' % (
                session.user_id.login or session.user_id.id, session.session_date),
            'presence_seconds': payload.get('presence_seconds') or 0.0,
            'productive_seconds': payload.get('productive_seconds') or 0.0,
            'paused_seconds': payload.get('paused_seconds') or 0.0,
            'standard_hours': payload.get('standard_hours') or 0.0,
            'met_standard': bool(payload.get('met_standard')),
            'task_count': payload.get('task_count') or 0,
            # Straight off the session — action_end_day() writes the note before it
            # captures, so this is the note just submitted. `or False` keeps an empty
            # note out of the column rather than storing ''.
            'note': (session.note or '').strip() or False,
            # Carried across a reopen: session.reverted stays set after the admin's
            # revert, so a re-ended day explains itself.
            'reopen_reason': (session.revert_reason or '').strip() or False,
            'reopened_by_id': session.reverted_by_id.id if session.reverted_by_id else False,
            'reopened_at': session.reverted_at or False,
            'generated_at': fields.Datetime.now(),
            # A redraw is a complete, current picture of the day, so it clears
            # any supersede left by an earlier reopen. Without this, a day that
            # was reopened and then properly re-ended would keep warning that
            # its summary is stale when it is the freshest thing there is.
            'superseded': False,
        }
        Snap = self.sudo()
        dom = [
            ('user_id', '=', session.user_id.id),
            ('session_date', '=', session.session_date),
        ]
        rec = Snap.search(dom, limit=1)
        if rec:
            rec.write(vals)
        else:
            # SAVEPOINT around the INSERT, because search-then-create is
            # check-then-act against UNIQUE (user_id, session_date) and it loses:
            # the 5-minute midnight cron and the daily one BOTH call
            # _close_overdue(), so two workers can search (finding nothing) and
            # then create the same day.
            #
            # Without the savepoint the duplicate aborted the whole TRANSACTION.
            # The caller's try/except swallowed the Python exception, but the
            # cursor was already dead, so every later statement in that cron run
            # failed with "current transaction is aborted" — losing the snapshot,
            # the daily summary, AND every session still to be closed in that run.
            # Observed on 2026-07-19 (session 180). The savepoint scopes the
            # failure to this one INSERT and leaves the transaction usable.
            try:
                with self.env.cr.savepoint():
                    rec = Snap.create(vals)
            except IntegrityError:
                # The other writer won. Same developer, same day — so write ours
                # over theirs and keep the rule that the last redraw wins.
                rec = Snap.search(dom, limit=1)
                if not rec:
                    raise
                rec.write(vals)
        _logger.info("workday snapshot saved: %s %s (%s bytes)",
                     session.user_id.login, session.session_date, len(png))
        return rec

    # ------------------------------------------------------------------ #
    # Retention — daily cron clears old images                           #
    # ------------------------------------------------------------------ #
    @api.model
    def _gc_snapshot_images(self):
        """Clear snapshot PNGs older than the company's configured retention.

        Only the image (a filestore attachment) is dropped — the lightweight
        stats row (date / presence / productive / tasks / met_standard) is kept
        so historical numbers survive. Writing False to the attachment=True
        Binary deletes the underlying ir.attachment file.

        Retention comes from res.company.kpi_snapshot_retention_number/_unit;
        number <= 0 means keep forever (no-op). Called by the daily cron in
        data/kpi_snapshot_cleanup_cron.xml — mirrors kpi.notification._gc_notifications.
        """
        company = self.env.company
        number = company.kpi_snapshot_retention_number or 0
        if number <= 0:
            return 0
        unit = company.kpi_snapshot_retention_unit or 'months'
        cutoff = fields.Date.context_today(self) - relativedelta(**{unit: number})
        old = self.sudo().search([
            ('session_date', '<', cutoff),
            ('image', '!=', False),
        ])
        count = len(old)
        if old:
            old.write({'image': False, 'image_name': False})
        _logger.info("snapshot image GC: cleared %s image(s) older than %s (%s %s)",
                     count, cutoff, number, unit)
        return count
