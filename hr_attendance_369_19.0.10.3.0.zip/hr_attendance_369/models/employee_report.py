from odoo import models, fields, api, exceptions
from datetime import date, timedelta
import calendar
import io
import base64
import logging

from .time_utils import minutes_to_hm

_logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
#  WIZARD – collects filter parameters
# ──────────────────────────────────────────────────────────────
class EmployeeReportWizard(models.TransientModel):
    _name = 'hr.employee.report.wizard'
    _description = 'Employee Report Wizard'

    month = fields.Selection([
        ('1', 'January'), ('2', 'February'), ('3', 'March'),
        ('4', 'April'), ('5', 'May'), ('6', 'June'),
        ('7', 'July'), ('8', 'August'), ('9', 'September'),
        ('10', 'October'), ('11', 'November'), ('12', 'December'),
    ], string='Month', required=True,
       default=lambda self: str(date.today().month))

    year = fields.Integer(
        string='Year', required=True,
        default=lambda self: date.today().year,
    )

    company_id = fields.Many2one(
        'res.company', string='Company',
        default=lambda self: self.env.company,
        required=True,
    )

    employee_select = fields.Selection([
        ('all', 'All Employees'),
        ('selected', 'Selected Employees'),
    ], string='Employees', default='all', required=True)

    employee_ids = fields.Many2many('hr.employee', string='Select Employees')
    department_id = fields.Many2one('hr.department', string='Department')

    def action_generate_report(self):
        self.ensure_one()
        month = int(self.month)
        year = self.year
        d_from = date(year, month, 1)
        last_day = calendar.monthrange(year, month)[1]
        d_to = date(year, month, last_day)

        report = self.env['hr.employee.report'].create({
            'month': self.month,
            'year': year,
            'date_from': d_from,
            'date_to': d_to,
            'company_id': self.company_id.id,
            'employee_select': self.employee_select,
            'employee_ids': [(6, 0, self.employee_ids.ids)] if self.employee_select == 'selected' else [(5,)],
            'department_id': self.department_id.id or False,
        })
        report.action_refresh()

        return {
            'name': report.name,
            'type': 'ir.actions.act_window',
            'res_model': 'hr.employee.report',
            'res_id': report.id,
            'view_mode': 'form',
            'target': 'current',
        }


# ──────────────────────────────────────────────────────────────
#  REPORT – main model that stores parameters and lines
# ──────────────────────────────────────────────────────────────
class EmployeeReport(models.Model):
    _name = 'hr.employee.report'
    _description = 'Employee Monthly Report'
    _order = 'create_date desc'

    name = fields.Char(string='Report Name', compute='_compute_name', store=True)

    # ── Parameters ───────────────────────────────────────────
    month = fields.Selection([
        ('1', 'January'), ('2', 'February'), ('3', 'March'),
        ('4', 'April'), ('5', 'May'), ('6', 'June'),
        ('7', 'July'), ('8', 'August'), ('9', 'September'),
        ('10', 'October'), ('11', 'November'), ('12', 'December'),
    ], string='Month')
    year = fields.Integer(string='Year')
    date_from = fields.Date(string='From', required=True)
    date_to = fields.Date(string='To', required=True)
    company_id = fields.Many2one('res.company', string='Company')
    currency_id = fields.Many2one(
        'res.currency', string='Currency',
        related='company_id.currency_id', readonly=True,
    )
    employee_select = fields.Selection([
        ('all', 'All Employees'),
        ('selected', 'Selected Employees'),
    ], string='Employee Filter', default='all')
    employee_ids = fields.Many2many('hr.employee', string='Employees')
    department_id = fields.Many2one('hr.department', string='Department')

    # ── Lines ────────────────────────────────────────────────
    summary_line_ids = fields.One2many(
        'hr.employee.report.summary.line', 'report_id', string='Employee Summary',
    )
    detail_line_ids = fields.One2many(
        'hr.employee.report.detail.line', 'report_id', string='Detailed Entries',
    )

    # ── Grand Totals (computed) ──────────────────────────────
    grand_leave_deduction = fields.Float(
        compute='_compute_grand_totals', string='Total Leave Deductions',
    )
    grand_total_deduction = fields.Float(
        compute='_compute_grand_totals', string='Grand Total Deductions',
    )
    grand_wage = fields.Float(
        compute='_compute_grand_totals', string='Total Wages',
    )
    grand_final_amount = fields.Float(
        compute='_compute_grand_totals', string='Grand Final Amount',
    )

    # ── Computed Fields ──────────────────────────────────────
    @api.depends('month', 'year')
    def _compute_name(self):
        month_names = dict(self._fields['month'].selection)
        for rec in self:
            if rec.month and rec.year:
                rec.name = f"Employee Report - {month_names.get(rec.month, '')} {rec.year}"
            else:
                rec.name = 'Employee Report'

    @api.depends('summary_line_ids.leave_deduction',
                 'summary_line_ids.total_deduction', 'summary_line_ids.wage',
                 'summary_line_ids.final_amount')
    def _compute_grand_totals(self):
        for rec in self:
            lines = rec.summary_line_ids
            rec.grand_leave_deduction = sum(lines.mapped('leave_deduction'))
            rec.grand_total_deduction = sum(lines.mapped('total_deduction'))
            rec.grand_wage = sum(lines.mapped('wage'))
            rec.grand_final_amount = sum(lines.mapped('final_amount'))

    # ── Refresh / Generate Data ──────────────────────────────
    def action_refresh(self):
        for rec in self:
            rec.summary_line_ids.unlink()
            rec.detail_line_ids.unlink()
            rec._generate_data()
        return True

    def _get_employees(self):
        domain = [('company_id', '=', self.company_id.id)]
        if self.employee_select == 'selected' and self.employee_ids:
            domain.append(('id', 'in', self.employee_ids.ids))
        if self.department_id:
            domain.append(('department_id', '=', self.department_id.id))
        return self.env['hr.employee'].search(domain)

    def _fix_jsonb_columns(self):
        cr = self.env.cr
        fixes = [
            ('hr_employee_report_summary_line', ['employee_name', 'department_name']),
            ('hr_employee_report_detail_line', ['employee_name']),
        ]
        for table, cols in fixes:
            for col in cols:
                cr.execute("""
                    SELECT data_type FROM information_schema.columns
                    WHERE table_name = %s AND column_name = %s
                """, (table, col))
                result = cr.fetchone()
                if result and result[0] in ('json', 'jsonb'):
                    _logger.info('Fixing JSONB column: %s.%s → varchar', table, col)
                    cr.execute(
                        'ALTER TABLE "%s" DROP COLUMN "%s"' % (table, col)
                    )
                    cr.execute(
                        'ALTER TABLE "%s" ADD COLUMN "%s" varchar' % (table, col)
                    )

    def _generate_data(self):
        """Build summary and detail lines from hr.attendance + hr.leave.request."""
        self.ensure_one()
        self._fix_jsonb_columns()

        employees = self._get_employees()
        d_from = self.date_from
        d_to = self.date_to

        Config = self.env['hr.attendance.late.config']
        Holiday = self.env['hr.public.holiday']
        summary_vals = []
        detail_vals = []

        for emp in employees:
            emp_name = emp.name or ''
            dept_name = emp.department_id.name if emp.department_id else ''

            config_data = Config.get_config_for_employee(emp.id)
            config_rec = Config.get_config_record_for_employee(emp.id)
            working_days_list = config_data.get('working_days', [0, 1, 2, 3, 4, 5])

            def calc_leave_deduction_live(leave_record, _emp=emp):
                """Calculate leave deduction live using salary-based formula — never trust stale stored value.

                Daily rate = monthly wage ÷ working days in the month (the same
                `total_working_days` figure this report computes, which excludes
                Sundays and public holidays). This makes a full month of unpaid
                leave wipe the wage exactly, and keeps the report consistent
                with the absence rate.
                """
                if leave_record.unpaid_days <= 0:
                    return 0.0
                leave_cfg = self.env['hr.leave.config'].search(
                    [('company_id', '=', _emp.company_id.id)], limit=1
                )
                if not leave_cfg or not leave_cfg.unpaid_leave_deduction_enabled:
                    return 0.0
                _wage = _emp.monthly_wage or 0.0
                if _wage <= 0 or total_working_days <= 0:
                    return 0.0
                # Round the daily rate to currency precision FIRST, then per
                # record — so one day = wage/working-days rounded to 2dp (e.g.
                # 185.19) and N days = that × N (185.19×5 = 925.95). This matches
                # the leave request's stored deduction_amount exactly.
                daily_rate = round(_wage / total_working_days, 2)
                return round(leave_record.unpaid_days * daily_rate, 2)


            # ── Calculate working days in the month ──────────
            # The configured weekdays, minus public holidays. Sundays are out
            # because Sunday is unchecked in the working-days boxes, and
            # holidays are excluded here — which is exactly what makes both of
            # them PAID: they never enter this divisor, so a full month of
            # attendance earns the whole wage and neither day is deductible.
            total_working_days = 0.0
            working_dates = set()
            current_date = d_from
            while current_date <= d_to:
                if current_date.weekday() in working_days_list:
                    if not Holiday.is_public_holiday(current_date, emp.company_id.id):
                        total_working_days += 1
                        working_dates.add(current_date)
                current_date += timedelta(days=1)

            _working_cache = {}

            def _is_working_date(day, _emp=emp):
                if d_from <= day <= d_to:
                    return day in working_dates
                if day not in _working_cache:
                    _working_cache[day] = (
                        day.weekday() in working_days_list
                        and not Holiday.is_public_holiday(day, _emp.company_id.id))
                return _working_cache[day]

            # ── Get all attendance records for this employee ─
            all_attendance = self.env['hr.attendance'].search([
                ('employee_id', '=', emp.id),
                ('date', '>=', d_from),
                ('date', '<=', d_to),
            ], order='date asc, check_in asc')

            # Get dates the employee actually came to work
            present_dates = set()
            for att in all_attendance:
                if att.date:
                    present_dates.add(att.date)

            # Only working days earn pay. A weekly off or public holiday that
            # was worked is repaid as a compensatory off (hr.comp.off.credit),
            # exactly as the payslip treats it -- counting it here as well
            # would pay the same day twice and let it mask a weekday absence.
            earning_present_dates = present_dates & working_dates
            total_present_days = float(len(earning_present_dates))

            # ── DAY STATUS LADDER ───────────────────────────
            # hr.attendance.day.status grades each day (present / late / half
            # day / absent) against the configured office-hour thresholds. Read
            # it here so the day-wise lines can show the graded label - which is
            # what carries the bracketed start time for somebody who began late
            # but owes nothing - and so half days reduce what the month earned.
            #
            # Absent days were never in present_dates, so they were never
            # earned in the first place — the report needs no absence deduction
            # of its own.
            day_status_info = {}
            for _ds in self.env['hr.attendance.day.status'].sudo().search([
                    ('employee_id', '=', emp.id),
                    ('date', '>=', d_from),
                    ('date', '<=', d_to),
            ]):
                day_status_info[_ds.date] = _ds

            # ── LATE DATA ───────────────────────────────────
            # Two filters replace what `late_sequence > 0` used to encode:
            #   * _past_late_window  — an arrival after the late window is
            #     graded Present and costs nothing, so it is not a "late day";
            #   * _is_day_first_checkin — the arrival is counted once.
            # Applied in Python because both are office-timezone decisions the
            # ORM cannot express in a domain.
            late_candidates = self.env['hr.attendance'].search([
                ('employee_id', '=', emp.id),
                ('is_late', '=', True),
                ('late_minutes', '>', 0),
                ('date', '>=', d_from),
                ('date', '<=', d_to),
            ], order='check_in asc')
            late_records = late_candidates.filtered(
                lambda a: not a._past_late_window(config_data)
                and a._is_day_first_checkin(config_data)
            )

            all_late_times = 0
            late_times_charged = 0
            total_late_minutes = 0
            late_dates_seen = set()
            late_date_info = {}  # date -> list of attendance records

            for att in late_records:
                all_late_times += 1
                if att.date not in late_date_info:
                    late_date_info[att.date] = []
                late_date_info[att.date].append(att)
                late_dates_seen.add(att.date)
                total_late_minutes += att.late_minutes
                late_times_charged += 1

            # ── LEAVE DATA ───────────────────────────────────
            # Leaves that OVERLAP this month, not merely those that START in
            # it. Selecting on from_date alone charged a leave crossing a month
            # boundary entirely to the month it began in, and made it vanish
            # from the next month's report altogether.
            #
            # to_date is optional -- empty means a single day -- so the second
            # half of the overlap test has to allow for that.
            leave_records = self.env['hr.leave.request'].search([
                ('hr_employee_id', '=', emp.id),
                ('state', '=', 'approved'),
                ('from_date', '<=', str(d_to)),
                '|',
                '&', ('to_date', '=', False), ('from_date', '>=', str(d_from)),
                ('to_date', '>=', str(d_from)),
            ], order='from_date asc')

            # Leave Policy changes (e.g. unchecking Paid Leave) are NOT
            # dependencies of `_compute_paid_status`, so the stored
            # paid_days/unpaid_days can be stale. Force a fresh recompute so
            # the report always reflects the current policy — same
            # "never trust stale stored value" stance used for late deductions.
            if leave_records:
                leave_records._compute_paid_status()

            total_paid_days = 0.0
            total_unpaid_days = 0.0
            # Comp-off days are a SUBSET of total_paid_days, never an addition
            # to it: the day is paid, and the money model must go on seeing it
            # as paid. This is kept only so the summary can report it on its
            # own line, the same split the payslip makes.
            total_comp_off_days = 0.0
            total_leave_deduction = 0.0
            total_leave_only_ded = 0.0  # unpaid-LEAVE deductions only (no absence)
            leave_date_info = {}  # date -> leave record

            type_labels = dict(
                self.env['hr.leave.request']._fields['leave_type'].selection
            )

            # Paid portion of each leave day inside this month, keyed by date.
            # Needed twice below: to total the month's paid days, and to net off
            # days that are ALSO present days.
            paid_leave_by_date = {}
            # Unpaid portion of each leave day inside this month, so each
            # day-wise line carries its own share of the deduction.
            unpaid_leave_by_date = {}

            for lr in leave_records:
                lr_start = lr.from_date
                lr_end = lr.to_date or lr.from_date

                # number_of_days counts WORKING days only, so spread it over
                # the working days of the span. Spreading over calendar days
                # would put leave on the Sundays and holidays inside it and
                # mis-split a leave that crosses a month boundary.
                lr_dates = []
                lr_current = lr_start
                while lr_current <= lr_end:
                    if _is_working_date(lr_current):
                        lr_dates.append(lr_current)
                    lr_current += timedelta(days=1)

                # A leave can be worth less than one day per day (a half day is
                # number_of_days 0.5 over a single date), so spread its value
                # evenly rather than assuming 1.0 per date.
                per_day = (lr.number_of_days / len(lr_dates)) if lr_dates else 0.0

                # Quota is consumed chronologically -- the first paid_days of a
                # leave are the paid ones and the remainder is unpaid -- so walk
                # the whole leave in order and only COUNT the days that fall
                # inside this month. Apportioning by proportion instead would
                # split a part-paid leave across a boundary incorrectly.
                paid_budget = lr.paid_days
                paid_in_range = 0.0
                unpaid_in_range = 0.0

                for lr_current in lr_dates:
                    day_paid = min(per_day, paid_budget)
                    paid_budget -= day_paid
                    if d_from <= lr_current <= d_to:
                        leave_date_info[lr_current] = lr
                        paid_in_range += day_paid
                        unpaid_in_range += (per_day - day_paid)
                        if day_paid:
                            paid_leave_by_date[lr_current] = (
                                paid_leave_by_date.get(lr_current, 0.0) + day_paid)
                        if per_day - day_paid:
                            unpaid_leave_by_date[lr_current] = (
                                unpaid_leave_by_date.get(lr_current, 0.0)
                                + (per_day - day_paid))

                total_paid_days += paid_in_range
                total_unpaid_days += unpaid_in_range
                if lr.leave_type == 'comp_off':
                    total_comp_off_days += paid_in_range

                # The deduction is unpaid_days x daily rate, so apportioning it
                # by unpaid days is exact rather than approximate.
                _lr_ded = calc_leave_deduction_live(lr)
                if lr.unpaid_days:
                    _lr_ded = round(_lr_ded * (unpaid_in_range / lr.unpaid_days), 2)
                else:
                    _lr_ded = 0.0
                total_leave_deduction += _lr_ded
                total_leave_only_ded += _lr_ded  # leave-request deductions only

            # Days the ladder graded as half, netted off earned_days below.
            #
            # Derived from the day-status rows, NOT collected while the day-wise
            # lines are built. It used to be gathered inside the `is_present`
            # branch, which meant a late arrival that ALSO worked under the
            # half-day ratio took the `has_late` branch and was never added --
            # so it was docked half a day on its day-status row while still
            # earning a full day here. Which detail line a day happens to render
            # as must not decide what it is worth.
            #
            # Leave dates are excluded so a leave day is never netted twice; the
            # leave accounting below already prices those.
            ladder_half_dates = {
                d for d, ds in day_status_info.items()
                if ds.status == 'half_day' and d not in leave_date_info
            }

            # ── BUILD DAY-WISE DETAIL LINES ──────────────────
            # Today (user timezone) — days after this haven't happened yet, so a
            # working day with no data is "not arrived", not absent/not-entered.
            report_today = fields.Date.context_today(self)
            # Office timezone for displaying check-in/out (config → employee → UTC),
            # so the report reads the same office time for everyone.
            import pytz as _pytz
            report_tz = _pytz.timezone(config_data.get('timezone') or emp.tz or 'UTC')

            def _office_time(dt):
                return _pytz.utc.localize(dt).astimezone(report_tz).strftime('%I:%M %p') if dt else ''

            current_date = d_from
            day_seq = 0
            while current_date <= d_to:
                is_working = current_date.weekday() in working_days_list
                is_holiday = Holiday.is_public_holiday(current_date, emp.company_id.id)
                is_expected = is_working

                # Determine what happened on this day
                has_leave = current_date in leave_date_info
                has_late = current_date in late_date_info
                is_present = current_date in present_dates

                # Skip non-working days (weekends) unless they have data
                if not is_expected and not is_holiday and not has_leave and not is_present:
                    current_date += timedelta(days=1)
                    continue

                day_seq += 1

                # Determine day type
                if is_holiday:
                    day_type = 'holiday'
                    holiday_rec = Holiday.search([
                        ('date', '=', current_date),
                        ('company_id', '=', emp.company_id.id),
                    ], limit=1)
                    description = f"Holiday: {holiday_rec.name}" if holiday_rec else 'Public Holiday'
                    detail_vals.append({
                        'report_id': self.id,
                        'employee_id': emp.id,
                        'employee_name': emp_name,
                        'department_name': dept_name,
                        'entry_date': current_date,
                        'day_type': 'holiday',
                        'description': description,
                        'check_in_time': '',
                        'late_minutes': 0,
                        'late_minutes_display': '',
                        'late_reason': '',
                        'leave_type': False,
                        'leave_paid_type': '',
                        'leave_reason': '',
                        'leave_deduction': 0,
                        'is_half_day': False,
                    })
                elif has_leave:
                    lr = leave_date_info[current_date]
                    leave_label = type_labels.get(lr.leave_type, lr.leave_type)
                    paid_type = 'Paid' if lr.is_paid else ('Unpaid' if lr.unpaid_days > 0 and lr.paid_days == 0 else 'Partial')

                    # If employee also came late on this leave day, show first late
                    check_in_str = ''
                    check_out_str = ''
                    late_min = 0
                    late_min_disp = ''
                    late_reas = ''
                    if has_late:
                        att = late_date_info[current_date][0]  # first late of the day
                        check_in_str = _office_time(att.check_in)
                        check_out_str = _office_time(att.check_out)
                        late_min = att.late_minutes
                        late_min_disp = minutes_to_hm(att.late_minutes)
                        late_reas = att.late_reason or ''

                    detail_vals.append({
                        'report_id': self.id,
                        'employee_id': emp.id,
                        'employee_name': emp_name,
                        'department_name': dept_name,
                        'entry_date': current_date,
                        'day_type': 'leave',
                        'description': f"{leave_label}" + (" (Half Day)" if lr.is_half_day else ""),
                        'check_in_time': check_in_str,
                        'check_out_time': check_out_str,
                        'late_minutes': late_min,
                        'late_minutes_display': late_min_disp,
                        'late_reason': late_reas,
                        'leave_type': lr.leave_type,
                        'leave_paid_type': paid_type,
                        'leave_reason': lr.reason or '',
                        # This day's share of the leave's deduction, apportioned
                        # by unpaid days the same way the summary does, so the
                        # day-wise total matches it for cross-month leaves too.
                        'leave_deduction': round(
                            calc_leave_deduction_live(lr)
                            * unpaid_leave_by_date.get(current_date, 0.0)
                            / lr.unpaid_days, 2) if lr.unpaid_days else 0.0,
                        'is_half_day': lr.is_half_day,
                    })
                elif has_late:
                    # Create one detail line per late occurrence on this day
                    late_atts = late_date_info[current_date]
                    for att in late_atts:
                        check_in_str = _office_time(att.check_in)
                        check_out_str = _office_time(att.check_out)
                        ds_late = day_status_info.get(current_date)
                        desc_parts = [ds_late.status_display if ds_late
                                      and ds_late.status_display else 'Late']

                        detail_vals.append({
                            'report_id': self.id,
                            'employee_id': emp.id,
                            'employee_name': emp_name,
                            'department_name': dept_name,
                            'entry_date': current_date,
                            'day_type': 'late',
                            'description': ' '.join(desc_parts),
                            'check_in_time': check_in_str,
                            'check_out_time': check_out_str,
                            'late_minutes': att.late_minutes,
                            'late_minutes_display': minutes_to_hm(att.late_minutes),
                            'late_reason': att.late_reason or '',
                            'leave_type': False,
                            'leave_paid_type': '',
                            'leave_reason': '',
                            'leave_deduction': 0,
                            'is_half_day': False,
                        })
                elif is_present:
                    # Normal present day. all_attendance is ordered by
                    # check_in asc, so the first row for this date IS the
                    # earliest arrival — which is the one that grades the day.
                    first_att = None
                    for att in all_attendance:
                        if att.date == current_date:
                            first_att = att
                            break
                    check_in_str = _office_time(first_att.check_in) if first_att else ''
                    check_out_str = _office_time(first_att.check_out) if first_att else ''

                    # What the ladder made of this day. `status_display` is
                    # the label plus the real start time in brackets whenever
                    # the person started late - including the case that costs
                    # nothing, which is exactly the one that would otherwise be
                    # invisible on this report.
                    ds = day_status_info.get(current_date)
                    is_ladder_half = bool(ds) and ds.status == 'half_day'

                    if is_ladder_half:
                        base_label = ds.status_display or 'Half Day'
                    else:
                        base_label = (ds.status_display if ds else '') or 'Present'

                    detail_vals.append({
                        'report_id': self.id,
                        'employee_id': emp.id,
                        'employee_name': emp_name,
                        'department_name': dept_name,
                        'entry_date': current_date,
                        'day_type': 'half_day' if is_ladder_half else 'present',
                        'description': base_label,
                        'check_in_time': check_in_str,
                        'check_out_time': check_out_str,
                        'late_minutes': 0,
                        'late_minutes_display': '',
                        'late_reason': '',
                        'leave_type': False,
                        'leave_paid_type': '',
                        'leave_reason': '',
                        'leave_deduction': 0,
                        'is_half_day': is_ladder_half,
                    })
                elif is_expected and not is_holiday:
                    # Expected working day with no attendance and no leave.
                    # Future days haven't arrived yet → don't show them at all.
                    if current_date > report_today:
                        current_date += timedelta(days=1)
                        continue
                    # Past/today working day with nothing entered → "Not Entered"
                    # (data-entry pending). In the earnings model it simply isn't
                    # earned, so it's already reflected in Final / Total Deduction;
                    # the "Leave Deduction" column stays for leave requests only.
                    detail_vals.append({
                        'report_id': self.id,
                        'employee_id': emp.id,
                        'employee_name': emp_name,
                        'department_name': dept_name,
                        'entry_date': current_date,
                        'day_type': 'absent',
                        'description': 'Absent',
                        'check_in_time': '',
                        'late_minutes': 0,
                        'late_minutes_display': '',
                        'late_reason': '',
                        'leave_type': False,
                        'leave_paid_type': '',
                        'leave_reason': '',
                        'leave_deduction': 0,
                        'is_half_day': False,
                    })

                current_date += timedelta(days=1)

            # ── WAGE ─────────────────────────────────────────
            emp_wage = emp.monthly_wage or 0.0

            # ── EARNINGS-BASED FINAL AMOUNT ──────────────────
            # Final = pay actually earned − late deductions. The employee earns
            # one day's wage (wage ÷ working days) for every day worked: present
            # days plus any PAID leave. Absent days and
            # unpaid leave are simply not earned; split-shift auto half-days (only
            # one session worked) earn half. Late arrivals reduce the earned pay.
            #   1 present day on a 5000/27 wage → 185.19 earned − late → Final.
            # Daily rate is rounded to currency precision (185.19) and used for
            # every multiple, so report figures match a manual 185.19×N calc and
            # the leave-request deductions exactly.
            daily_rate = round(emp_wage / total_working_days, 2) if total_working_days > 0 else 0.0
            # A half day is still a present day (they did check in), so
            # total_present_days counted it as a whole one. Net off the other
            # half here.
            # A day that is BOTH a present day and a paid-leave day was being
            # earned twice -- once through total_present_days, once through
            # total_paid_days. Net the overlap off rather than dropping either,
            # because both totals are reported in their own right and must stay
            # true individually.
            double_counted = sum(
                paid_leave_by_date.get(_d, 0.0) for _d in earning_present_dates)
            earned_days = max(0.0, total_present_days + total_paid_days
                              - 0.5 * len(ladder_half_dates)
                              - double_counted)
            earned = round(daily_rate * earned_days, 2)
            # Rounding the rate up can make a full month's earnings exceed the wage
            # by a few paise — cap so 100% attendance pays exactly the wage.
            if earned > emp_wage:
                earned = emp_wage
            # Lateness costs nothing now, so earned IS the final amount before
            # the leave split below. Only half days (already netted out of
            # earned_days) and unpaid leave reduce pay.
            final_amt = round(earned, 2)
            # Show the unpaid-LEAVE deduction on its own column. Total Deduction is
            # then everything else not received (absent days, half days). So the
            # three reconcile to the wage:
            #   Total Deduction + Leave Deduction + Final = Wage.
            leave_ded = round(total_leave_only_ded, 2)
            total_ded = round(max(0.0, emp_wage - final_amt - leave_ded), 2)

            summary_vals.append({
                'report_id': self.id,
                'employee_id': emp.id,
                'employee_name': emp_name,
                'department_name': dept_name,
                'total_working_days': total_working_days,
                'total_present_days': total_present_days,
                'total_late_days_raw': all_late_times,
                'late_days': late_times_charged,
                'late_minutes': total_late_minutes,
                'late_minutes_display': minutes_to_hm(total_late_minutes),
                # Paid leave EXCLUDING comp off, so the two columns can be
                # read side by side without double counting. Their sum is still
                # every paid day taken.
                'paid_leave_days': total_paid_days - total_comp_off_days,
                'unpaid_leave_days': total_unpaid_days,
                'comp_off_days': total_comp_off_days,
                'leave_deduction': leave_ded,
                'wage': emp_wage,
                'total_deduction': total_ded,
                'final_amount': final_amt,
            })

        # Batch create
        if summary_vals:
            self.env['hr.employee.report.summary.line'].create(summary_vals)
        if detail_vals:
            self.env['hr.employee.report.detail.line'].create(detail_vals)

    # ── PDF Export ────────────────────────────────────────────
    def action_print_pdf(self):
        return self.env.ref(
            'hr_attendance_369.action_report_employee_pdf'
        ).report_action(self)

    # ── Excel Export ─────────────────────────────────────────
    def action_export_excel(self):
        self.ensure_one()
        try:
            import xlsxwriter
        except ImportError:
            raise exceptions.UserError(
                'xlsxwriter is required for Excel export. '
                'Install it with: pip install xlsxwriter'
            )

        output = io.BytesIO()
        wb = xlsxwriter.Workbook(output, {'in_memory': True})

        # ── Styles ───────────────────────────────────────────
        title_fmt = wb.add_format({
            'bold': True, 'font_size': 16, 'align': 'left',
        })
        header_fmt = wb.add_format({
            'bold': True, 'font_size': 10, 'bg_color': '#875A7B',
            'font_color': 'white', 'border': 1, 'align': 'center',
            'valign': 'vcenter', 'text_wrap': True,
        })
        cell_fmt = wb.add_format({
            'font_size': 10, 'border': 1, 'align': 'left',
            'valign': 'vcenter',
        })
        num_fmt = wb.add_format({
            'font_size': 10, 'border': 1, 'align': 'right',
            'valign': 'vcenter', 'num_format': '#,##0.00',
        })
        int_fmt = wb.add_format({
            'font_size': 10, 'border': 1, 'align': 'center',
            'valign': 'vcenter',
        })
        total_label_fmt = wb.add_format({
            'bold': True, 'font_size': 10, 'border': 1,
            'align': 'right', 'bg_color': '#F2F2F2',
        })
        total_num_fmt = wb.add_format({
            'bold': True, 'font_size': 10, 'border': 1,
            'align': 'right', 'bg_color': '#F2F2F2',
            'num_format': '#,##0.00',
        })
        total_int_fmt = wb.add_format({
            'bold': True, 'font_size': 10, 'border': 1,
            'align': 'center', 'bg_color': '#F2F2F2',
        })
        info_label = wb.add_format({'bold': True, 'font_size': 10})
        info_value = wb.add_format({'font_size': 10})

        month_names = dict(self._fields['month'].selection)

        # ═══════════════════════════════════════════════════
        #  SHEET 1: Employee Summary
        # ═══════════════════════════════════════════════════
        ws1 = wb.add_worksheet('Employee Summary')
        ws1.set_landscape()
        ws1.set_paper(9)

        ws1.merge_range('A1:M1', 'Employee Statement Report', title_fmt)
        ws1.write('A3', 'Company:', info_label)
        ws1.write('B3', self.company_id.name or '', info_value)
        ws1.write('A4', 'Period:', info_label)
        ws1.write('B4', f"{month_names.get(self.month, '')} {self.year}", info_value)

        row = 6
        summary_headers = [
            'Employee', 'Department', 'Working\nDays', 'Present\nDays',
            'Late Days', 'Total Late\nTime',
            'Paid Leave\nDays', 'Unpaid Leave\nDays', 'Comp Off\nDays',
            'Leave\nDeduction', 'Monthly\nWage', 'Total\nDeduction', 'Final\nAmount',
        ]
        col_widths = [25, 20, 10, 10, 12, 12, 12, 12, 12, 14, 14, 14, 14]
        for c, (hdr, w) in enumerate(zip(summary_headers, col_widths)):
            ws1.set_column(c, c, w)
            ws1.write(row, c, hdr, header_fmt)

        row += 1
        for line in self.summary_line_ids:
            ws1.write(row, 0, line.employee_name or '', cell_fmt)
            ws1.write(row, 1, line.department_name or '', cell_fmt)
            ws1.write(row, 2, line.total_working_days, int_fmt)
            ws1.write(row, 3, line.total_present_days, int_fmt)
            ws1.write(row, 4, line.late_days, int_fmt)
            ws1.write(row, 5, line.late_minutes_display or '0:00', cell_fmt)
            ws1.write(row, 6, line.paid_leave_days, num_fmt)
            ws1.write(row, 7, line.unpaid_leave_days, num_fmt)
            ws1.write(row, 8, line.comp_off_days, num_fmt)
            ws1.write(row, 9, line.leave_deduction, num_fmt)
            ws1.write(row, 10, line.wage, num_fmt)
            ws1.write(row, 11, line.total_deduction, num_fmt)
            ws1.write(row, 12, line.final_amount, num_fmt)
            row += 1

        # Totals row
        ws1.merge_range(row, 0, row, 1, 'Grand Total', total_label_fmt)
        ws1.write(row, 2, sum(self.summary_line_ids.mapped('total_working_days')), total_int_fmt)
        ws1.write(row, 3, sum(self.summary_line_ids.mapped('total_present_days')), total_int_fmt)
        ws1.write(row, 4, sum(self.summary_line_ids.mapped('late_days')), total_int_fmt)
        ws1.write(row, 5, '', total_int_fmt)
        ws1.write(row, 6, sum(self.summary_line_ids.mapped('paid_leave_days')), total_num_fmt)
        ws1.write(row, 7, sum(self.summary_line_ids.mapped('unpaid_leave_days')), total_num_fmt)
        ws1.write(row, 8, sum(self.summary_line_ids.mapped('comp_off_days')), total_num_fmt)
        ws1.write(row, 9, self.grand_leave_deduction, total_num_fmt)
        ws1.write(row, 10, self.grand_wage, total_num_fmt)
        ws1.write(row, 11, self.grand_total_deduction, total_num_fmt)
        ws1.write(row, 12, self.grand_final_amount, total_num_fmt)

        # ═══════════════════════════════════════════════════
        #  SHEET 2: Detailed Day-wise Entries
        # ═══════════════════════════════════════════════════
        ws2 = wb.add_worksheet('Detailed Entries')
        ws2.set_landscape()
        ws2.set_paper(9)

        ws2.merge_range('A1:N1', 'Detailed Day-wise Entries', title_fmt)
        ws2.write('A3', 'Period:', info_label)
        ws2.write('B3', f"{month_names.get(self.month, '')} {self.year}", info_value)

        row = 4
        detail_headers = [
            'Date', 'Employee', 'Department', 'Day Type', 'Description',
            'Check In', 'Check Out', 'Late Time', 'Late Reason',
            'Leave Type', 'Leave (Paid/Unpaid)', 'Leave Reason',
            'Leave Ded.',
        ]
        detail_widths = [12, 22, 18, 10, 25, 12, 12, 10, 20, 12, 14, 20, 12]
        for c, (hdr, w) in enumerate(zip(detail_headers, detail_widths)):
            ws2.set_column(c, c, w)
            ws2.write(row, c, hdr, header_fmt)

        row += 1
        sorted_details = self.detail_line_ids.sorted(
            key=lambda r: (r.employee_name or '', r.entry_date)
        )
        for dl in sorted_details:
            ws2.write(row, 0, str(dl.entry_date) if dl.entry_date else '', cell_fmt)
            ws2.write(row, 1, dl.employee_name or '', cell_fmt)
            ws2.write(row, 2, dl.department_name or '', cell_fmt)
            ws2.write(row, 3, dict(dl._fields['day_type'].selection).get(dl.day_type, ''), cell_fmt)
            ws2.write(row, 4, dl.description or '', cell_fmt)
            ws2.write(row, 5, dl.check_in_time or '', cell_fmt)
            ws2.write(row, 6, dl.check_out_time or '', cell_fmt)
            ws2.write(row, 7, dl.late_minutes_display or '', cell_fmt)
            ws2.write(row, 8, dl.late_reason or '', cell_fmt)
            leave_label = dict(self.env['hr.leave.request']._fields['leave_type'].selection).get(dl.leave_type, '') if dl.leave_type else ''
            ws2.write(row, 9, leave_label, cell_fmt)
            ws2.write(row, 10, dl.leave_paid_type or '', cell_fmt)
            ws2.write(row, 11, dl.leave_reason or '', cell_fmt)
            ws2.write(row, 12, dl.leave_deduction, num_fmt)
            row += 1

        # Totals
        ws2.merge_range(row, 0, row, 11, 'Grand Total Deductions', total_label_fmt)
        ws2.write(row, 12, sum(self.detail_line_ids.mapped('leave_deduction')), total_num_fmt)

        wb.close()

        file_name = f"Employee_Report_{month_names.get(self.month, '')}_{self.year}.xlsx"
        attachment = self.env['ir.attachment'].sudo().create({
            'name': file_name,
            'type': 'binary',
            'datas': base64.b64encode(output.getvalue()),
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        })
        output.close()

        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'new',
        }


# ──────────────────────────────────────────────────────────────
#  SUMMARY LINE – one row per employee
# ──────────────────────────────────────────────────────────────
class EmployeeReportSummaryLine(models.Model):
    _name = 'hr.employee.report.summary.line'
    _description = 'Employee Report Summary Line'
    _order = 'employee_name asc'

    @api.model
    def _auto_init(self):
        cr = self.env.cr
        cr.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = %s AND column_name IN %s AND data_type = 'jsonb'
        """, (self._table, ('employee_name', 'department_name')))
        for (col,) in cr.fetchall():
            _logger.info('Fixing column type: %s.%s from jsonb to varchar', self._table, col)
            cr.execute(
                'ALTER TABLE "' + self._table + '" DROP COLUMN "' + col + '"'
            )
        return super()._auto_init()

    report_id = fields.Many2one(
        'hr.employee.report', string='Report',
        required=True, ondelete='cascade', index=True,
    )
    currency_id = fields.Many2one(
        'res.currency', related='report_id.company_id.currency_id', readonly=True,
    )
    employee_id = fields.Many2one('hr.employee', string='Employee', readonly=True)
    employee_name = fields.Char(string='Employee', readonly=True)
    department_name = fields.Char(string='Department', readonly=True)

    # Attendance
    total_working_days = fields.Float(string='Working Days', readonly=True)
    total_present_days = fields.Float(string='Present Days', readonly=True)

    # Late tracking
    late_days = fields.Integer(string='Late Days', readonly=True)
    total_late_days_raw = fields.Integer(string='Total Late Days (Raw)', readonly=True)
    late_minutes = fields.Integer(string='Total Late (Min)', readonly=True)
    late_minutes_display = fields.Char(string='Total Late Time', readonly=True)

    # Leave tracking
    paid_leave_days = fields.Float(string='Paid Leave Days', readonly=True)
    unpaid_leave_days = fields.Float(string='Unpaid Leave Days', readonly=True)
    comp_off_days = fields.Float(
        string='Comp Off Days', readonly=True,
        help='Days taken back as compensatory off for working a weekly off or '
             'a public holiday. Paid, but spending no leave allowance, so it '
             'is counted apart from Paid Leave Days rather than inside it.')
    leave_deduction = fields.Float(string='Leave Deduction', readonly=True)

    # Wage & Final
    wage = fields.Float(string='Wage', readonly=True)
    total_deduction = fields.Float(string='Total Deduction', readonly=True)
    final_amount = fields.Float(string='Final Amount', readonly=True)

    # ── Drill-down Actions ───────────────────────────────────
    def action_view_day_details(self):
        """Open day-wise detail lines for this employee from the report."""
        self.ensure_one()
        details = self.report_id.detail_line_ids.filtered(
            lambda d: d.employee_id.id == self.employee_id.id
        )
        view_id = self.env.ref('hr_attendance_369.view_detail_line_list').id
        search_view_id = self.env.ref('hr_attendance_369.view_detail_line_search').id
        return {
            'name': f'Day-wise Details – {self.employee_name}',
            'type': 'ir.actions.act_window',
            'res_model': 'hr.employee.report.detail.line',
            'view_mode': 'list',
            'views': [(view_id, 'list')],
            'search_view_id': search_view_id,
            'domain': [('id', 'in', details.ids)],
            'context': {'create': False},
            'target': 'current',
        }

    def action_view_late_records(self):
        self.ensure_one()
        report = self.report_id
        return {
            'name': f'Late Records – {self.employee_name}',
            'type': 'ir.actions.act_window',
            'res_model': 'hr.attendance',
            'view_mode': 'list,form',
            'domain': [
                ('employee_id', '=', self.employee_id.id),
                ('is_late', '=', True),
                ('date', '>=', str(report.date_from)),
                ('date', '<=', str(report.date_to)),
            ],
            'context': {'create': False},
            'target': 'current',
        }

    def action_view_leave_records(self):
        self.ensure_one()
        report = self.report_id
        return {
            'name': f'Leave Records – {self.employee_name}',
            'type': 'ir.actions.act_window',
            'res_model': 'hr.leave.request',
            'view_mode': 'list,form',
            'domain': [
                # Same overlap test as _generate_data, so a leave that began
                # last month is listed too.
                ('hr_employee_id', '=', self.employee_id.id),
                ('state', '=', 'approved'),
                ('from_date', '<=', str(report.date_to)),
                '|',
                '&', ('to_date', '=', False), ('from_date', '>=', str(report.date_from)),
                ('to_date', '>=', str(report.date_from)),
            ],
            'context': {'create': False},
            'target': 'current',
        }


# ──────────────────────────────────────────────────────────────
#  DETAIL LINE – one row per day per employee
# ──────────────────────────────────────────────────────────────
class EmployeeReportDetailLine(models.Model):
    _name = 'hr.employee.report.detail.line'
    _description = 'Employee Report Detail Line'
    _order = 'employee_name asc, entry_date asc'

    @api.model
    def _auto_init(self):
        cr = self.env.cr
        cr.execute("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = %s AND column_name IN %s AND data_type = 'jsonb'
        """, (self._table, ('employee_name',)))
        for (col,) in cr.fetchall():
            _logger.info('Fixing column type: %s.%s from jsonb to varchar', self._table, col)
            cr.execute(
                'ALTER TABLE "' + self._table + '" DROP COLUMN "' + col + '"'
            )
        return super()._auto_init()

    report_id = fields.Many2one(
        'hr.employee.report', string='Report',
        required=True, ondelete='cascade', index=True,
    )
    currency_id = fields.Many2one(
        'res.currency', related='report_id.company_id.currency_id', readonly=True,
    )
    employee_id = fields.Many2one('hr.employee', string='Employee', readonly=True)
    employee_name = fields.Char(string='Employee', readonly=True)
    department_name = fields.Char(string='Department', readonly=True)

    entry_date = fields.Date(string='Date', readonly=True)
    day_type = fields.Selection([
        ('present', 'Present'),
        ('late', 'Late'),
        ('half_day', 'Half Day'),
        ('leave', 'Leave'),
        ('absent', 'Absent'),
        ('holiday', 'Holiday'),
    ], string='Day Type', readonly=True)

    description = fields.Char(string='Description', readonly=True)
    check_in_time = fields.Char(string='Check In Time', readonly=True)
    check_out_time = fields.Char(string='Check Out Time', readonly=True)
    is_half_day = fields.Boolean(string='Half Day', readonly=True)

    # Late info
    late_minutes = fields.Integer(string='Late (Min)', readonly=True)
    late_minutes_display = fields.Char(string='Late Time', readonly=True)
    late_reason = fields.Text(string='Late Reason', readonly=True)

    # Leave info
    # Mirrors hr.leave.request so a new leave type can never make report
    # generation fail with "Wrong value for leave_type".
    leave_type = fields.Selection(
        selection=lambda self: self.env['hr.leave.request']._fields['leave_type'].selection,
        string='Leave Type', readonly=True)
    leave_paid_type = fields.Char(string='Paid/Unpaid', readonly=True)
    leave_reason = fields.Text(string='Leave Reason', readonly=True)
    leave_deduction = fields.Float(string='Leave Deduction', readonly=True)
